﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class bird : MonoBehaviour
{
    public Rigidbody2D  rb2d; 
    public float speed = 50;
    bool isDead = false;
    public float jumpforce = 20;
    public GameObject ReplayButton;
    public Text ScoreText;
    int score;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 0;
        rb2d = GetComponent<Rigidbody2D>();
        rb2d.velocity = Vector2.right * speed * Time.deltaTime;
        ReplayButton.SetActive(false);
        
    }

    void Update()
    {
       
  if ( Input.GetKeyDown(KeyCode.Space) && !isDead) 
        {
          rb2d.AddForce(Vector2.up * jumpforce);
            rb2d.velocity = Vector2.right * speed;
        }
        
    }
    void OnCollisionEnter2D(Collision2D col)
    {
        isDead = true;
        rb2d.velocity = Vector2.zero;
        GetComponent<Animator>().SetBool("death", true);
        ReplayButton.SetActive(true);

    }
    public void Replay()
    {
        SceneManager.LoadScene(0);
    }
    public void Unfreeze()
    {
        Time.timeScale = 1;
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.name == "score")
        {
            score++;
            ScoreText.text = score.ToString();
        }
    }
}
