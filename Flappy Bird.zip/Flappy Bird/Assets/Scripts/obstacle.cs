﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacle : MonoBehaviour
{
     public float minY;
    public float maxY;
    public float distance;

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Obstacle")
        {
            float obstacley = Random.Range(minY, maxY);

            Vector3 spawnposition = new Vector3 (transform.position.x + distance , obstacley , 0);

            col.gameObject.transform.position = spawnposition;
        }

    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
